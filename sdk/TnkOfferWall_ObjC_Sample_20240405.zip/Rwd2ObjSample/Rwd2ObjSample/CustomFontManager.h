//
//  CustomFontManager.h
//  Rwd2ObjSample
//
//  Created by KyoungBeen.Seo on 2024/04/04.
//

#ifndef CustomFontManager_h
#define CustomFontManager_h
#import "TnkRwdSdk2/TnkRwdSdk2.h"

@interface CustomFontManager : NSObject <FontManager>

@end




#endif /* CustomFontManager_h */
