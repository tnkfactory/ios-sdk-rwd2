//
//  CustomFontManager.m
//  Rwd2ObjSample
//
//  Created by KyoungBeen.Seo on 2024/04/04.
//

#import <Foundation/Foundation.h>
#import "CustomFontManager.h"
#import <UIKit/UIKit.h>

@interface CustomFontManager()

@end


@implementation CustomFontManager

- (UIFont *)getFontOfSize:(CGFloat)ofSize{
    return [UIFont fontWithName:@"Arial" size:ofSize];
}

- (UIFont * _Nonnull)getBoldFontOfSize:(CGFloat)ofSize { 
    return [UIFont boldSystemFontOfSize:ofSize];
}


- (UIFont * _Nonnull)getFontOfSize:(CGFloat)ofSize weight:(UIFontWeight)weight { 
    return [UIFont systemFontOfSize:ofSize weight:weight];
}


- (UIFont * _Nonnull)getItalicFontOfSize:(CGFloat)ofSize { 
    return [UIFont italicSystemFontOfSize:ofSize];
}


@end
