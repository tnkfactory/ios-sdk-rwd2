//
//  ViewController.m
//  Rwd2ObjSample
//
//  Created by KyoungBeen.Seo on 2024/04/04.
//

#import "ViewController.h"
#import "AppTrackingTransparency/AppTrackingTransparency.h"
#import "TnkRwdSdk2/TnkRwdSdk2.h"
#import "CustomFontManager.h"

@interface ViewController ()

@end

@implementation ViewController

//MARK: - ViewController Life cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initOfferWall];
    // 앱 추적 동의창 띄우기
    [TnkAlerts showATTPopup:self agreeAction:^{
        
    } denyAction:^{
        
    }];
}

//MARK: - 오퍼월 초기화
-(void)initOfferWall{
    //[ 중요!! ] - 게시상태가 "테스트"인 프로젝트에서는 광고 목록이 노출되지 않습니다.
    //개발과정에서 광고 목록을 노출하시려면
    //https://github.com/tnkfactory/android-sdk-rwd/blob/master/reg_test_device.md
    //첨부된 링크의 내용에 따라 IDFA값을 별도 테스트 기기로 등록해야 합니다.
    
    [TnkSession initInstanceWithAppId:@"your-app-id-from-tnk-site"]; //APP-ID 설정
    [[TnkSession sharedInstance] setUserName:@"<user name>"]; //사용자 식별값 설정
    [self setCutomDesign];
}

-(void)setCutomDesign{
    //https://github.com/tnkfactory/ios-sdk-rwd2/blob/main/UI_Customizing.md#4-%EC%83%88%EB%A1%9C%EC%9A%B4-Layout-%EA%B5%AC%ED%98%84%ED%95%98%EA%B8%B0
    //커스터마이징 과정중 6.새로운 Layout 구현하기 내용은 Objective-C를 지원하지 않습니다.
    
    //폰트 변경 - CustomFontManager.m 참고
    [[TnkFonts shared] setFontManager:[[CustomFontManager alloc] init]];
    
    //순서에 유의해주세요.
    //1.TnkColor 변경
    [self changeMainColor];
    //2.TnkStyle 변경
    [self setCustomStyle];
    //3.TnkLayout 변경
    [self setMenuFilter];
    [self setADListItemLayout];
//    [self changeRightIconAdlist]; //우측아이콘으로 설정
    [self changeFeedAdList]; //피드 형태로 설정
    
    //순으로 진행해야 디자인이 정상 반영됩니다.
    
}

//MARK: - AdOfferwallViewController(오퍼월 화면 호출)
- (IBAction)onTouchStartOfferWallBtn:(id)sender
{
    UIViewController *vc = [[AdOfferwallViewController alloc] init];
    vc.title = @"TEST Offerwall";

    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:vc];
    navController.modalPresentationStyle = UIModalPresentationFullScreen;
    navController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: UIColor.blackColor};

    [self presentViewController:navController animated:YES completion:nil];
}

//MARK: - 메인 칼라셋 변경
-(void)changeMainColor{
    TnkColor.PRIMARY_COLOR = [UIColor blackColor];
//    TnkColor.MAIN_BACKGROUND_COLOR = [self colorWith:113.0f green:114.0f blue:52.0f alpha:1];
}

//MARK: - 메뉴,필터 관리
-(void)setMenuFilter{
    TnkLayout *layout = [TnkLayout shared];
    [layout setMenuFilterHidden:true];//필터 숨김처리
//    [layout setMenuMenuHidden:true];//메뉴 숨김처리
}

//MARK: - Style 변경 예시
//https://github.com/tnkfactory/ios-sdk-rwd2/blob/main/UI_Customizing.md#TnkStyles
//TnksStyle 변경 예시
-(void)setCustomStyle{
    TnkStyles *styles = [TnkStyles shared];
    
    //광고 리스트 관련 스타일 변경
    AdListItemStyle *listStyle = [styles adListItem];
    
    //타이틀 관련 어트리뷰트 변경
    [[listStyle titleLabel] setColor:[self colorWith:80 green:70 blue:120 alpha:1]];
    [[listStyle titleLabel] setNumberOfLines:2];
    [[listStyle pointAmountLabel] setColor:[UIColor redColor]];
    //titleLabel : 제목
    //descLabel : "받으면","시청 후 클릭하면","미션 달성 시"..
    //pointAmountLabel : 포인트 금액
    
    //포인트 표기 라인 구조
    //[DescLabel] [pointIconImage] [pointAmountLabel] [pointUnitLabel]
    //"오픈하면,받으면" "아이콘 이미지" , "0" , "P - 별도 표기 라벨"
    //포인트 아이콘 숨김 처리
    [[[styles adListItem] pointIconImage] setImageNormal:nil];
//    [[[styles adListItem] pointIconImage] setImageNormal:[UIImage imageNamed:@"이미지 리소스 명"]]; - 별도 아이콘 사용시
    //포인트 표기 라벨에 단위 함께 표시 - 기본:{point}  , 함께표기시:{point}{unit} ,별도 커스터마이징 예시 : {point}원
    [[styles adListItem] setPointAmountFormat:@"{point}{unit}"];
    //포인트 표기 별도 라벨 숨김 처리
    [[styles adListItem] setPointUnitVisible:false];
}

//MARK: - AdList 레이아웃 변경 예시
//https://github.com/tnkfactory/ios-sdk-rwd2/blob/main/UI_Customizing.md#AdListItemViewLayout
//레이아웃 등록하기 예시
-(void)setADListItemLayout{

    AdListItemViewLayout *viewLayout = [[AdListItemViewLayout alloc] init];
    // iconImage 의 크기 변경, 라운드 없이 각지게 표시, 테두리 검은색으로 2 pixel
    ImageAttribute *iconImage = [viewLayout iconImage];
    [iconImage setWidth:80.0f];
    [iconImage setHeight:80.0f];
    [iconImage setCornerRadius:0];
    [iconImage setStrokeWidth:2.0f];
    [iconImage setStrokeColor:[UIColor blackColor]];
    
    // titleLabel 의 폰트 크기, 색상 변경
    LabelAttribute *titleLabel = [viewLayout titleLabel];
    [titleLabel setFont:[UIFont systemFontOfSize:17.0f]];
    [titleLabel setColor:[UIColor orangeColor]];
    
    // descLabel 안쪽으로 더 밀어넣기 (기본값 12)
    LabelAttribute *descLabel = [viewLayout descLabel];
    [descLabel setLeadingSpace:15.0f];
    
    // 포인트 명칭 숨기기
    [viewLayout setPointUnitVisible:false];
    // divider 두께 변경 및 양쪽 여백 없애기
    [viewLayout setDividerHeight:2.0f];
    [viewLayout setDividerLeadingSpace:0.f];
    [viewLayout setDividerTrailingSpace:0.f];
    
    // Layout 등록
    [[TnkLayout shared] registerItemViewLayoutWithType:LayoutTypeNormal
                                             viewClass:DefaultAdListItemView.class
                                            viewLayout:viewLayout];
}

//MARK: - RightIconAdListItemView 레이아웃 변경 예시
//https://github.com/tnkfactory/ios-sdk-rwd2/blob/main/UI_Customizing.md#righticonadlistitemview-feedadlistitemview
//RightIconAdListItemView 를 기본 광고 목록으로 지정하는 예시와 FeedAdListItemView 를 기본 광고 목록으로 지정하는 예시 코드
-(void)changeRightIconAdlist{
    AdListItemViewLayout *viewLayout = [[AdListItemViewLayout alloc] init];
    [viewLayout setSectionInset:UIEdgeInsetsMake(0.f, 10.f, 0.f, 10.f)];
    [viewLayout setItemInset:UIEdgeInsetsMake(6.f, 10.f, 7.f, 10.f)];
    [viewLayout setDividerLeadingSpace:10.f];
    [viewLayout setDividerTrailingSpace:10.f];
    // Layout 등록
    [[TnkLayout shared] registerItemViewLayoutWithType:LayoutTypeNormal
                                             viewClass:[RightIconAdListItemView class]
                                            viewLayout:viewLayout];
}

-(void)changeFeedAdList{
    FeedAdItemLargeViewLayout *viewLayout = [[FeedAdItemLargeViewLayout alloc] init];
    [viewLayout setSectionInset:UIEdgeInsetsMake(0.f, 10.f, 0.f, 10.f)];
    [viewLayout setItemInset:UIEdgeInsetsMake(6.f, 10.f, 7.f, 10.f)];
    [viewLayout setDividerLeadingSpace:10.f];
    [viewLayout setDividerTrailingSpace:10.f];
    // Layout 등록
    [[TnkLayout shared] registerItemViewLayoutWithType:LayoutTypeNormal
                                             viewClass:[FeedAdListItemView class]
                                            viewLayout:viewLayout];
}


//MARK: - Utility 함수
-(UIColor *)colorWith:(CGFloat)red green:(CGFloat)green blue:(CGFloat)blue alpha:(CGFloat)alpha{
    return [[UIColor alloc] initWithRed:red/255.0f green:green/255.0f blue:blue/255.0f alpha:alpha];
}

@end
