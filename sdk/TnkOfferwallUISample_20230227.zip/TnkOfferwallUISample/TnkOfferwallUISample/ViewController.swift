//
//  ViewController.swift
//  TnkOfferwallUISample
//
//  Created by  김동혁 on 2023/02/24.
//

import UIKit
import TnkRwdSdk2

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        TnkSession.initInstance(appId: "c01060e0-70d1-43f5-5f34-1d070e050302")
        TnkSession.sharedInstance()?.setUserName("testUser")
        
        TnkLayout.shared.registerItemViewLayout(type: .normal, viewClass: CustomAdListItemView.self, viewLayout: CustomAdListItemViewLayout())
        
        // Filter 메뉴 UI 변경
        let filterMenuLayout = AdListFilterViewLayout()
        filterMenuLayout.itemButton.backgroundSelected = UIColor.black
        filterMenuLayout.itemButton.backgroundHighlighted = UIColor.black
        
        TnkLayout.shared.registerMenuViewLayout(type: .filter, viewClass: AdListMenuFixedView.self, viewLayout: filterMenuLayout)
    }


    @IBAction
    func showOfferwall() {
        let vc = AdOfferwallViewController()
        vc.title = "TEST Offerwall"
        
        let navController = UINavigationController(rootViewController: vc)
        navController.modalPresentationStyle = .fullScreen
        navController.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.black]
        self.present(navController, animated: true)
    }
}

