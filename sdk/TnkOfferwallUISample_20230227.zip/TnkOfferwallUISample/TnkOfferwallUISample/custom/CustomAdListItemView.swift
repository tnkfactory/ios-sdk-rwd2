//
//  CustomAdListItemView.swift
//  TnkOfferwallUISample
//
//  Created by  김동혁 on 2023/02/24.
//

import UIKit
import TnkRwdSdk2

class CustomAdListItemView : AdListItemView {
    var itemView:CustomItemView?
    
    override init(frame:CGRect) {
        super.init(frame:frame)
        
        itemView = loadView()
        
        if let view = itemView {
            contentView.addSubview(view)
            NSLayoutConstraint.activate([
                view.leftAnchor.constraint(equalTo: contentView.leftAnchor),
                view.rightAnchor.constraint(equalTo: contentView.rightAnchor),
                view.topAnchor.constraint(equalTo: contentView.topAnchor),
                view.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            ])
            
            view.feedImageView.layer.cornerRadius = 16
            view.feedImageView.layer.borderWidth = 1
            view.feedImageView.layer.borderColor = UIColor.lightGray.cgColor
            
            view.iconImageView.layer.cornerRadius = 8
            view.iconImageView.layer.borderWidth = 1
            view.iconImageView.layer.borderColor = UIColor.lightGray.cgColor
        }
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func loadView() -> CustomItemView {
        let bundleName = Bundle(for: type(of: self))
        let nib = UINib(nibName: "CustomItemView", bundle: bundleName)
        let view = nib.instantiate(withOwner: nil, options: nil).first as! CustomItemView
        view.translatesAutoresizingMaskIntoConstraints = false
        
        return view
    }
    
    override func getFeedImageView() -> UIImageView? {
        return itemView?.feedImageView
    }
    
    override func getIconImageView() -> UIImageView? {
        return itemView?.iconImageView
    }
    
    override func useImageFeed() -> Bool {
        return true
    }
    
    override func useImageIcon() -> Bool {
        return true
    }
    
    override func setData(_ adItem: AdItem?, row: Int, itemsPerPage: Int, itemIndex: Int, numberOfItems: Int) {
        if let adItem = adItem as? AdListItem {
            itemView?.titleLabel.text = adItem.appName
            itemView?.pointUnitLabel.text = adItem.pointUnit
            
            if adItem.state == .confirm {
                itemView?.descLabel.text = ""
                itemView?.pointAmountLabel.text = "설치확인 후 리워드가 지급됩니다."
                itemView?.pointUnitLabel.isHidden = true
            }
            else if adItem.state == .paid {
                itemView?.descLabel.text = ""
                itemView?.pointAmountLabel.text = "이미 지급된 광고입니다."
                itemView?.pointUnitLabel.isHidden = true
            }
            else if adItem.state == .disabled || adItem.state == .ended {
                itemView?.descLabel.text = ""
                itemView?.pointAmountLabel.text = "종료된 광고입니다."
                itemView?.pointUnitLabel.isHidden = true
            }
            else {
                itemView?.descLabel.text = adItem.cmpnDesc
                itemView?.pointAmountLabel.text = adItem.pointText
                itemView?.pointUnitLabel.isHidden = false
            }
        }
    }
}

class CustomItemView : UIView {
    @IBOutlet var feedImageView:UIImageView!
    @IBOutlet var iconImageView:UIImageView!
    @IBOutlet var titleLabel:UILabel!
    @IBOutlet var descLabel:UILabel!
    @IBOutlet var pointAmountLabel:UILabel!
    @IBOutlet var pointUnitLabel:UILabel!
}
